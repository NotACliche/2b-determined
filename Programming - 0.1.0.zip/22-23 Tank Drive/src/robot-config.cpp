#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;


/* -------------------------------- brain and controllers -------------------------------- */
// brain declaration but not initialization
brain Brain;

// controller construction and initialization
controller controller_primary = controller(controllerType::primary);
controller controller_secondary = controller(controllerType::partner);

// include the config file to use the configured options
#include "config.h"


/* -------------------------------- drivetrain -------------------------------- */
// drivetrain motor declaration and initialization
motor motor_drivetrain_Left_Frnt = motor(port_motor_R_F, motor_cartridge_drivetrian, drivetrainReversed); // Not reversed from normal
motor motor_drivetrain_Left_Back = motor(port_motor_R_B, motor_cartridge_drivetrian, drivetrainReversed); // Not reversed from normal
motor motor_drivetrain_Left_Elev = motor(port_motor_R_E, motor_cartridge_drivetrian, !drivetrainReversed); // Reversed from the others because it is on a different rotation bearing
motor motor_drivetrain_Right_Frnt = motor(port_motor_R_F, motor_cartridge_drivetrian, !drivetrainReversed); // Right side is reversed from the left side
motor motor_drivetrain_Right_Back = motor(port_motor_R_B, motor_cartridge_drivetrian, !drivetrainReversed); // Right side is reversed from the left side
motor motor_drivetrain_Right_Elev = motor(port_motor_R_E, motor_cartridge_drivetrian, drivetrainReversed); // Reversed from the others because it is on a different rotation bearing

// drive side motor group declaration and initialization
motor_group driveLeft = motor_group(motor_drivetrain_Left_Frnt, motor_drivetrain_Left_Back, motor_drivetrain_Left_Elev);
motor_group driveRight = motor_group(motor_drivetrain_Right_Frnt, motor_drivetrain_Right_Back, motor_drivetrain_Right_Elev);

// drivetrain declaration and initialization
drivetrain mainDrive = drivetrain(driveLeft, driveRight);


/* -------------------------------- catapult -------------------------------- */
// catapult motor declaration and initialization
motor motor_catapult = motor(port_motor_catapult, motor_cartridge_catapult, motor_reversed_catapult);

// catapult limit swithch declaration and initialization
limit catapult_switch = limit(triport_switch_catapult);


/* -------------------------------- intake -------------------------------- */
// intake motor declaration and initialization
motor motor_intake = motor(port_motor_intake, motor_cartridge_intake, motor_reversed_intake);


/* -------------------------------- inertial/odometry -------------------------------- */
// inertial sensor declaration and initialization
inertial sensor_inertial = inertial(port_sensor_inertial);

// encoder initialization
rotation sensor_rotation_right = rotation(port_sensor_rotation_right, sensor_rotation_reversed_right);
rotation sensor_rotation_left = rotation(port_sensor_rotation_left, sensor_rotation_reversed_left);


/* -------------------------------- endgame -------------------------------- */
// endgame solenoid initialization
digital_out solenoid_endgame_1 = digital_out(triport_solenoid_endgame_1);
digital_out solenoid_endgame_2 = digital_out(triport_solenoid_endgame_2);


/* -------------------------------- drivetrain control -------------------------------- */
int rc_primaryController_loop() {
  // process the controller input every 20 milliseconds
  // and update the motors based on the input values
  while(true) {
    // get the controller joystick axes
    int drivetrain_left = abs(axis_drivetrain_left.position()) > axis_deadzone ? axis_drivetrain_left.position() : 0;
    int drivetrain_right = abs(axis_drivetrain_right.position()) > axis_deadzone ? axis_drivetrain_right.position() : 0;

    // set the drivetrain to the input axes
    driveLeft.spin(forward, drivetrain_left, percent);
    driveRight.spin(forward, drivetrain_right, percent);

    // wait before repeating the process
    wait(20, msec);
  }
  return 0;
}


/* -------------------------------- catapult control -------------------------------- */
void catapultEnabledCallback() {
  while (true) {
    if (!catapult_switch.pressing()) while (!catapult_switch.pressing()) {
      motor_catapult.spin(directionType::fwd, velocity_catapult_teleoperated, velocityUnits::pct);
      wait(10, timeUnits::msec);
    }
    if (button_catapult.pressing()) {
      while (catapult_switch.pressing()) {
        motor_catapult.spin(directionType::fwd, velocity_catapult_teleoperated, velocityUnits::pct);
        wait(10, timeUnits::msec);
      }
      continue;
    } else {
      motor_catapult.stop();
      return;
    }
  }
}


/* -------------------------------- intake control -------------------------------- */
void intakeEnabledCallback() {
  if (button_intake.pressing()) motor_intake.spin(directionType::fwd, velocity_intake_teleoperated, velocityUnits::pct);
  else if (button_reverse_intake.pressing()) motor_intake.spin(directionType::rev, velocity_intake_teleoperated, velocityUnits::pct);
}

void intakeDisabledCallback() {
  motor_intake.stop();
}


/* -------------------------------- solenoid control -------------------------------- */
bool solenoid_enabled = false;

void endgameCallback() {
  if (solenoid_enabled) {
    solenoid_endgame_1.set(false);
    solenoid_endgame_2.set(false);
    solenoid_enabled = false;
  } else {
    solenoid_endgame_1.set(true);
    solenoid_endgame_2.set(true);
    solenoid_enabled = true;
  }
}


/* -------------------------------- vexcode init -------------------------------- */
void vexcodeInit( void ) {
  // remote control loop
  task rc_auto_loop_task_primaryController(rc_primaryController_loop);

  // catapult button callback
  button_catapult.pressed(catapultEnabledCallback);

  // intake button callbacks
  button_intake.pressed(intakeEnabledCallback);
  button_intake.released(intakeDisabledCallback);
  button_reverse_intake.pressed(intakeEnabledCallback);
  button_reverse_intake.released(intakeDisabledCallback);

  // endgame button callback
  button_endgame.pressed(endgameCallback);
  
  // drivetrain setup
  mainDrive.setStopping(brake_type_drivetrain);

  // catapult setup
  motor_catapult.setStopping(brake_type_catapult);

  // intake setup
  motor_intake.setStopping(brake_type_intake);

  // calibrate the inertial sensor
  sensor_inertial.calibrate();

  // calibrate the tracking wheels
  sensor_rotation_left.resetPosition();
  sensor_rotation_right.resetPosition();
}