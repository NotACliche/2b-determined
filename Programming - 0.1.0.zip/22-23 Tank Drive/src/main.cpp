/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 2, 3, 4      
// Flywheel             motor_group   5, 6            
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#define _USE_MATH_DEFINES

#include "vex.h"
#include "cmath"
#include "odometry.h"
#include "autonomous.h"

using namespace vex;

// A global instance of competition
competition Competition;

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  // print stuff to the brain
  Brain.Screen.setFont(fontType::mono12);
  Brain.Screen.setCursor(40, 60);
  Brain.Screen.print("bitches be bonkers");
  
  wait(100, timeUnits::msec);
}

void autonomous(void) {

}

void driverControl(void) {
  while (true) {
    wait(100, msec);
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(driverControl);

  // Run the pre-autonomous function.
  pre_auton();
  // task odometryTask = task(updateValues);

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}