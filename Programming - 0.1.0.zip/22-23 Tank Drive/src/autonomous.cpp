#include "vex.h"
#include "cmath"
#include "odometry.h"
#include "pid.h"

/* ----- reset directional offsets ----- */
void resetSensors() {
  sensor_rotation_left.resetPosition();
  sensor_rotation_right.resetPosition();
  sensor_inertial.resetHeading();
}

bool within(double value, double target, double error) {
  if (value >= target - error && value <= target + error) return true;
  else return false;
}