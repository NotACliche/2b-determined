#include "vex.h"

double oldLeftDistance = 0, oldRightDistance = 0, oldStrafeDistance = 0, oldRotation = 0;
double resetLeft = 0, resetRight = 0;
double absX = 0, absY = 0, absRotation = 0;
double circumference = 8.639125;

void reset() {
  resetLeft = sensor_rotation_left.position(rotationUnits::rev) * circumference;
  resetRight = sensor_rotation_right.position(rotationUnits::rev) * circumference;
}

int updateValues() {
  while (true) {
    // double lateralOffset = 5.75, strafeOffset = 3.5;
    // double newLeftDistance = sensor_rotation_left.position(rotationUnits::rev) * circumference;
    // double newRightDistance = sensor_rotation_right.position(rotationUnits::rev) * circumference;
    // double deltaLeft = newLeftDistance - oldLeftDistance;
    // double deltaRight = newRightDistance - oldRightDistance;
    // double deltaLeftReset = newLeftDistance - resetLeft;
    // double deltaRightReset = newRightDistance - resetRight;
    // oldLeftDistance = newLeftDistance;
    // oldRightDistance = newRightDistance;
    // double newRotation = (deltaLeftReset - deltaRightReset) / (lateralOffset * 2);
    // double deltaRotation = newRotation - oldRotation;
    // double localY = 2 * sin(oldRotation / 2) * (deltaRight / deltaRotation + lateralOffset);
    // double theta = atan2(localY, localX);
    // double radius = sqrt(pow(localX, 2) + pow(localY, 2));
    // theta -= (oldRotation + deltaRotation / 2);
    // oldRotation = newRotation;
    // absRotation = newRotation;
    // absX += radius * cos(theta);
    // absY += radius * sin(theta);

    // controller_primary.Screen.clearScreen();
    // controller_primary.Screen.setCursor(1, 0);
    // controller_primary.Screen.print("bv: ");
    // controller_primary.Screen.print(Brain.Battery.voltage());
    // controller_primary.Screen.setCursor(2, 0);
    // controller_primary.Screen.print("rot: ");
    // controller_primary.Screen.print(absRotation);
    // controller_primary.Screen.setCursor(3, 0);
    // controller_primary.Screen.print("driv: ");
    // controller_primary.Screen.print(default_drive);
    // wait(10, msec);
  }
  return 0;
}