#include "vex.h"
#include "robot-config.h"

/* -------------------------------- drivetrain settings -------------------------------- */
// drivetrain motor ports
int32_t port_motor_R_F = vex::PORT1;
int32_t port_motor_R_B = vex::PORT2;
int32_t port_motor_R_E = vex::PORT3;
int32_t port_motor_L_F = vex::PORT4;
int32_t port_motor_L_B = vex::PORT5;
int32_t port_motor_L_E = vex::PORT6;

// drivetrain reversed
bool drivetrainReversed = false;

// drivetrain gear cartridge
gearSetting motor_cartridge_drivetrian = gearSetting::ratio18_1;

// drivetrain stopping
brakeType brake_type_drivetrain = brakeType::brake;


/* -------------------------------- catapult settings -------------------------------- */
// catapult motor port
int32_t port_motor_catapult = vex::PORT9;

// catapult reversed
bool motor_reversed_catapult = true;

// catapult gear cartridge
gearSetting motor_cartridge_catapult = gearSetting::ratio18_1;

// drivetrain stopping
brakeType brake_type_catapult = brakeType::hold;

// catapult limit switch port
triport::port triport_switch_catapult = Brain.ThreeWirePort.H;


/* -------------------------------- intake settings -------------------------------- */
// intake motor ports
int32_t port_motor_intake = vex::PORT1;

// intake reversed
bool motor_reversed_intake = true;

// intake motor cartridge
gearSetting motor_cartridge_intake = gearSetting::ratio18_1;

// drivetrain stopping
brakeType brake_type_intake = brakeType::brake;


/* -------------------------------- inertial sensor settings -------------------------------- */
// intertial sensor port
int32_t port_sensor_inertial = vex::PORT11;

// inertial sensor enabled
bool inerial_enabled = false;


/* -------------------------------- rotational sensors settings -------------------------------- */
// rotational sensor ports
int32_t port_sensor_rotation_left = vex::PORT18;
int32_t port_sensor_rotation_right = vex::PORT20;

// rotation sensor reversed
bool sensor_rotation_reversed_left = true;
bool sensor_rotation_reversed_right = false;


/* -------------------------------- solenoid settings -------------------------------- */
// solenoid ports
triport::port triport_solenoid_endgame_1 = Brain.ThreeWirePort.A;
triport::port triport_solenoid_endgame_2 = Brain.ThreeWirePort.B;


/* -------------------------------- manual control settings -------------------------------- */
// button designations
controller::button button_catapult = controller_primary.ButtonR2;
controller::button button_intake = controller_primary.ButtonL2;
controller::button button_reverse_intake = controller_primary.ButtonL1;
controller::button button_swap_drive_direction = controller_primary.ButtonRight;
controller::button button_endgame = controller_primary.ButtonX;

// joystick options
controller::axis axis_drivetrain_left = controller_primary.Axis3;
controller::axis axis_drivetrain_right = controller_primary.Axis2;
float axis_deadzone = 2;


/* -------------------------------- motor speed settings -------------------------------- */
float velocity_drivetrain_teleoperated = 100;
float velocity_catapult_teleoperated = 100;
float velocity_intake_teleoperated = 69;
float velocity_drivetrain_autonomous = 100;
float velocity_catapult_autonomous = 100;
float velocity_intake_autonomous = 69;