using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller controller_primary;
extern controller controller_secondary;
extern motor_group driveLeft;
extern motor_group driveRight;
extern drivetrain mainDrive;
extern motor motor_catapult;
extern motor motor_intake;
extern inertial sensor_inertial;
extern rotation sensor_rotation_left;
extern rotation sensor_rotation_right;
extern digital_out solenoid_endgame_1;
extern digital_out solenoid_endgame_2;

/*
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);