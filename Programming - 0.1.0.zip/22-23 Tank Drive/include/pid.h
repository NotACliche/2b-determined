typedef struct { // init a reusable list of variables
	double current; // sensor value
	double kP; // value factor
	double kI; // value factor
	double kD; // value factor
	double target; // init
  double start;
	double error; // calc 1, target - actual
	double lastError; // save 1,
	double integral; // calc 2, += error
	double derivative; // calc 2, -= lastError
  double kIDisable;
  void set(double newTargetDistance, double newDisable) {
    target = newTargetDistance + current;
    start = current;
    kIDisable = newDisable;
    error = target - current;
    lastError = target - current;
    integral = 0;
    derivative = 0;
  }
  double calculate() {
    // calculate the error value
    error = target - current;
    double proportional = error;
    // proportional = (error / (target - start)) * 100;

    // calculate the integral adjustment
    integral += error; // add the current error
    if (error >= kIDisable) integral = 0; // reset to 0 if within constraints
    else if (error * integral < 0) integral /= -2; // take back half, might remove later

    // calculate the derivative adjustment
    derivative = error - lastError; // subtract the previous error

    // set the last error
    lastError = error;

    // return the calculated values
    return proportional * kP + integral * kI + derivative * kD;
  }
  void setK(double kPn, double kIn, double kDn) {
    kP = kPn;
    kI = kIn;
    kD = kDn;
  }
} pid;

pid lPID, sPID, rPID;