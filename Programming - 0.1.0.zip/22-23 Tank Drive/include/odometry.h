extern int updateValues();
extern double absX, absY, absRotation;