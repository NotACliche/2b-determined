extern void forwardFor(double, int);
extern void strafeFor(double, int);
extern void rotateFor(double, double);
extern void moveFor(double, double, double);
extern void resetSensors();